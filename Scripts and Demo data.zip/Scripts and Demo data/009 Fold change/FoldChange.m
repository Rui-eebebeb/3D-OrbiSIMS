% MATLAB Script to Compute Fold Change and Export Results

% Select file using a dialog box
[filename, filepath] = uigetfile('*.xlsx', 'Select an Excel file');
if filename == 0
    error('No file selected. Please select a valid Excel file.');
end
fullFileName = fullfile(filepath, filename);

% Load the selected Excel file with original column names preserved
data = readtable(fullFileName, 'VariableNamingRule', 'preserve');

% Identify numeric columns (excluding non-numeric ones)
numericColumns = varfun(@isnumeric, data, 'OutputFormat', 'uniform');
numericData = data(:, numericColumns); % Keep only numeric data

% Convert table to numeric array
numericArray = table2array(numericData);

% Get the number of samples
numSamples = size(numericArray, 1);

% Define groups (Fixing indexing issue)
group1_idx = 1:floor(numSamples/2);  % First half of samples
group2_idx = ceil(numSamples/2):numSamples;  % Second half of samples

% Compute mean for each group
mean_group1 = mean(numericArray(group1_idx, :), 1);
mean_group2 = mean(numericArray(group2_idx, :), 1);

% Fix division by zero issue
mean_group2(mean_group2 == 0) = eps; % Replace zeros with a small number

% Compute fold change and log2 fold change
fold_change = mean_group1 ./ mean_group2;
log2_fold_change = log2(fold_change);

% Create results table
feature_names = numericData.Properties.VariableNames';
results = table(feature_names, fold_change', log2_fold_change', ...
    'VariableNames', {'Ion', 'Fold_Change', 'Log2_Fold_Change'});

% Ensure Ion column is treated as text
results.Ion = string(results.Ion);

% Check if Ion column is numeric (convert if needed for sorting)
numericIons = str2double(results.Ion);
if all(~isnan(numericIons))  % If all values are numeric
    results.Ion = numericIons;  % Convert to numeric
    results = sortrows(results, 'Ion', 'ascend');  % Sort numerically
else
    results = sortrows(results, 'Ion', 'ascend');  % Sort alphabetically
end

% Save results to an Excel file in the same directory as the input file
output_filename = fullfile(filepath, ['Fold_Change_Results_', filename]);
writetable(results, output_filename);

disp(['Fold change results saved to: ', output_filename]);
