clear; clc;

% --- Ask about normalization and log10 transformation ---
choice = questdlg('Do you want to normalize intensities to sum and apply log10(x + 1) transform before the t-test?', ...
                  'Data Preprocessing Options', ...
                  'Yes', 'No', 'Cancel', 'Yes');

if strcmp(choice, 'Cancel')
    error('Operation cancelled by the user.');
end

normalizeAndLog = strcmp(choice, 'Yes');

% --- Select Excel File ---
[fileName, filePath] = uigetfile('*.xlsx', 'Select the Excel File for T-Test Analysis');
if isequal(fileName, 0)
    error('No file selected. Process aborted.');
end

inputFile = fullfile(filePath, fileName);
outputFile = fullfile(filePath, ['TTest_BH_Corrected_' fileName]);

% --- Read first sheet from the Excel file ---
[~, sheetNames] = xlsfinfo(inputFile);
sheetToRead = sheetNames{1};  % Use the first sheet
dataTable = readtable(inputFile, 'Sheet', sheetToRead, 'VariableNamingRule', 'preserve');

% --- Remove accidental header row inside data ---
badRows = strcmpi(string(dataTable{:,2}), "group");
if any(badRows)
    disp('Removing row(s) with invalid group label "group":');
    disp(dataTable(badRows, :));
    dataTable(badRows, :) = [];
end

% --- Extract sample names and group labels ---
sampleNames = dataTable{:, 1};
rawGroupLabels = dataTable{:, 2};
groupLabels = strtrim(string(rawGroupLabels));  % Clean whitespace

% --- Validate number of groups ---
uniqueGroups = unique(groupLabels);
if numel(uniqueGroups) ~= 2
    disp('Detected group labels:');
    disp(uniqueGroups);
    error('The dataset must contain exactly two groups for t-test analysis.');
end

% --- Split sample indices for the two groups ---
group1Idx = strcmp(groupLabels, uniqueGroups(1));
group2Idx = strcmp(groupLabels, uniqueGroups(2));

% --- Extract intensity matrix and ion names ---
intensityMatrix = table2array(dataTable(:, 3:end));
ionNames = dataTable.Properties.VariableNames(3:end);
ionNumbers = str2double(ionNames);

% --- Normalize and log10 transform if selected ---
if normalizeAndLog
    % Normalize each row to its total sum
    rowSums = sum(intensityMatrix, 2);
    intensityMatrix = intensityMatrix ./ rowSums;
    % Log10(x + 1) transform to stabilize variance
    intensityMatrix = log10(intensityMatrix + 1);
end

% --- Prepare group data ---
group1Data = intensityMatrix(group1Idx, :);
group2Data = intensityMatrix(group2Idx, :);

% --- Perform Welch's t-test ---
numIons = size(intensityMatrix, 2);
pValues = nan(1, numIons);
tStats = nan(1, numIons);

for i = 1:numIons
    [~, pValues(i), ~, stats] = ttest2(group1Data(:, i), group2Data(:, i), 'Vartype', 'unequal');
    tStats(i) = stats.tstat;
end

% --- Benjamini-Hochberg FDR correction ---
[sortedP, sortIdx] = sort(pValues);
m = length(sortedP);
adjusted = sortedP .* m ./ (1:m);
adjusted = min(adjusted, 1);
for i = m-1:-1:1
    adjusted(i) = min(adjusted(i), adjusted(i+1));
end
finalAdjustedPValues = nan(size(pValues));
finalAdjustedPValues(sortIdx) = adjusted;

% --- Calculate log2 Fold Change (Group2 vs Group1) ---
meanGroup1 = mean(group1Data, 1);
meanGroup2 = mean(group2Data, 1);

if normalizeAndLog
    % Data is in log10 scale → convert difference to log2FC
    log2FC = (meanGroup2 - meanGroup1) * log2(10);
else
    % Raw scale → use log2 of ratio
    log2FC = log2(meanGroup2 ./ meanGroup1);
end

% --- Count significant ions ---
numSignificant = sum(finalAdjustedPValues < 0.05);
fprintf('Number of significant ions (FDR < 0.05): %d\n', numSignificant);

% --- Build results table ---
resultsTable = table(ionNumbers', pValues', finalAdjustedPValues', tStats', log2FC', ...
    'VariableNames', {'Ion_mz', 'Raw_PValue', 'Adjusted_PValue', 'T_Statistic', 'Log2FC'});

% --- Sort by m/z and export to Excel ---
resultsTable = sortrows(resultsTable, 'Ion_mz');
writetable(resultsTable, outputFile, 'Sheet', 'T-Test Results', 'WriteMode', 'overwrite');

% --- Notify success ---
fprintf('Results saved to: %s\n', outputFile);
msgbox(sprintf('T-Test completed!\nSignificant ions: %d', numSignificant), 'Success', 'modal');
