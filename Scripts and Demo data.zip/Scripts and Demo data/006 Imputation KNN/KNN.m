% Custom KNN Imputation Script (No knnimpute)
% - Handles multiple Excel files separately.
% - Computes KNN manually using Euclidean distance.
% - Ensures KNN does not fail even with sparse data.

clear; clc;

% --- Select Excel Files ---
[fileNames, filePath] = uigetfile('*.xlsx', 'Select One or More Excel Files for KNN Imputation', 'MultiSelect', 'on');

% Check if the user canceled the selection
if isequal(fileNames, 0)
    error('No file selected. Process aborted.');
end

% Ensure fileNames is a cell array (for single-file selection)
if ischar(fileNames)
    fileNames = {fileNames};
end

% --- Process Each Selected File ---
for i = 1:length(fileNames)
    inputFile = fullfile(filePath, fileNames{i});
    outputFile = fullfile(filePath, ['KNN_Imputed_' fileNames{i}]);

    % Get sheet names dynamically
    [~, sheetNames] = xlsfinfo(inputFile);
    
    % Select "Filtered Data" sheet if available
    if any(strcmp(sheetNames, 'Filtered Data'))
        sheetToRead = 'Filtered Data';
    else
        sheetToRead = sheetNames{1}; % Default to first sheet
    end

    % Read the Excel file
    dataTable = readtable(inputFile, 'Sheet', sheetToRead, 'VariableNamingRule', 'preserve');
    sampleNames = dataTable.Sample;
    intensityMatrix = table2array(dataTable(:, 2:end));

    % Convert zeros to NaN before KNN imputation
    intensityMatrix(intensityMatrix == 0) = NaN;

    % Remove rows (samples) that are entirely NaN
    validRows = ~all(isnan(intensityMatrix), 2);
    intensityMatrix = intensityMatrix(validRows, :);
    sampleNames = sampleNames(validRows);

    % Ensure that there are enough valid data points
    if all(isnan(intensityMatrix(:)))
        error('All data points are missing after preprocessing. Try reducing filtering thresholds.');
    end

    % Normalize before KNN (to match Python)
    meanVals = nanmean(intensityMatrix);
    stdVals = nanstd(intensityMatrix);
    stdVals(stdVals == 0) = 1; % Avoid division by zero
    intensityMatrix = (intensityMatrix - meanVals) ./ stdVals;

    % --- Automatically Determine k ---
    nonNaNCounts = sum(~isnan(intensityMatrix), 1);
    autoK = max(3, min(10, floor(median(nonNaNCounts) / 2)));

    fprintf('Automatically selected k=%d for file: %s\n', autoK, fileNames{i});

    % --- Custom KNN Imputation ---
    [numSamples, numFeatures] = size(intensityMatrix);

    for row = 1:numSamples
        for col = 1:numFeatures
            if isnan(intensityMatrix(row, col))
                % Compute distances to all other rows
                validIndices = ~isnan(intensityMatrix(:, col));
                distances = sqrt(sum((intensityMatrix(validIndices, :) - intensityMatrix(row, :)).^2, 2));

                % Sort by distance and select k nearest neighbors
                [sortedDistances, sortedIdx] = sort(distances, 'ascend');
                nearestNeighbors = sortedIdx(1:min(autoK, sum(validIndices)));

                % Compute weighted mean from nearest neighbors
                weights = 1 ./ (sortedDistances(1:length(nearestNeighbors)) + 1e-6); % Avoid division by zero
                weights = weights / sum(weights); % Normalize weights

                % Fill missing value
                intensityMatrix(row, col) = sum(weights .* intensityMatrix(nearestNeighbors, col), 'omitnan');
            end
        end
    end

    % Denormalize data
    imputedMatrix = (intensityMatrix .* stdVals) + meanVals;

    % Convert back to DataFrame
    imputedTable = array2table(imputedMatrix, 'VariableNames', dataTable.Properties.VariableNames(2:end));
    imputedTable = addvars(imputedTable, sampleNames, 'Before', 1, 'NewVariableNames', {'Sample'});

    % Save the processed data
    writetable(imputedTable, outputFile, 'Sheet', 'KNN Imputed Data', 'WriteMode', 'overwrite');

    fprintf('KNN imputed data saved to: %s\n', outputFile);
end

fprintf('Processing completed for all selected files.\n');
msgbox('KNN Imputation completed successfully!', 'Success', 'modal');
