% MS Peak Alignment Using Hierarchical Clustering (Corrected)
% Aligns peaks from multiple MS data files based on mass tolerance (±5 ppm)
% Outputs an Excel file with aligned peaks and intensities (Samples in Rows)
% Generates a Heatmap and Scatter Plot labeled "Aligned MS Peaks"

clear; clc;

% Define parameters
massTolerancePPM = 5; % ±5 ppm tolerance for peak alignment
outputFileName = 'Aligned_MS_Peaks.xlsx';

% Select multiple experimental sample files
[expFiles, expPath] = uigetfile('*.txt', 'Select Experimental Sample Files', 'MultiSelect', 'on');

if isequal(expFiles, 0)
    error('No experimental samples selected.');
end

% Ensure expFiles is a cell array for consistency
if ischar(expFiles)
    expFiles = {expFiles};
end

% Initialize storage for peak alignment
allMZ = []; % Store all m/z values for clustering
sampleData = cell(length(expFiles), 2); % Store sample names & intensities
intensityData = cell(length(expFiles), 1); % Store intensity data separately

% Read each file and extract m/z and intensity values
for i = 1:length(expFiles)
    filePath = fullfile(expPath, expFiles{i});
    
    % Read data, skipping the header
    data = readmatrix(filePath, 'FileType', 'text');
    
    % Extract m/z and intensity values
    mzValues = data(:, 1);
    intensities = data(:, 2);
    
    % Store data for alignment
    allMZ = [allMZ; mzValues]; % Collect all m/z values
    sampleData{i, 1} = erase(expFiles{i}, '.txt'); % Store sample name
    sampleData{i, 2} = mzValues; % Store m/z for this sample
    intensityData{i} = intensities; % Store intensity data for this sample
end

% Sort all collected m/z values
allMZ = unique(sort(allMZ));

% Perform Hierarchical Clustering for Peak Alignment
massTolerance = allMZ * massTolerancePPM / 1e6; % Convert ppm to absolute mass error

% Create distance matrix based on m/z differences
distanceMatrix = pdist(allMZ);

% Perform hierarchical clustering
Z = linkage(distanceMatrix, 'single'); % Single linkage clustering

% Define cluster cutoff based on mass tolerance
clusterThreshold = max(massTolerance); 
clusters = cluster(Z, 'cutoff', clusterThreshold, 'criterion', 'distance');

% Determine representative m/z for each cluster (correct averaging)
alignedMZ = accumarray(clusters, allMZ, [], @mean);

% Initialize aligned intensity matrix (Samples in Rows)
alignedIntensities = zeros(length(expFiles), length(alignedMZ));

% Assign intensities to aligned peaks
for i = 1:length(expFiles)
    samplePeaks = sampleData{i, 2}; % Get m/z values for this sample
    sampleIntensities = intensityData{i}; % Get intensity values
    
    % Assign intensities to the closest aligned m/z values
    for j = 1:length(samplePeaks)
        % Find the closest aligned m/z within ±5 ppm
        mzDiff = abs(alignedMZ - samplePeaks(j)) ./ samplePeaks(j) * 1e6;
        closestIdx = find(mzDiff <= massTolerancePPM, 1); % Find index of closest match
        
        if ~isempty(closestIdx)
            alignedIntensities(i, closestIdx) = sampleIntensities(j); % Assign intensity
        end
    end
end

% Sort aligned m/z values in ascending order before exporting
[alignedMZ, sortIdx] = sort(alignedMZ); % Sort m/z values
alignedIntensities = alignedIntensities(:, sortIdx); % Apply sorting to intensity matrix

% Prepare data for exporting (samples in rows)
exportData = cell(length(expFiles) + 1, length(alignedMZ) + 1);
exportData(1, 1) = {'Sample'}; % Header for sample names
exportData(1, 2:end) = cellfun(@(x) sprintf('%.4f', x), num2cell(alignedMZ'), 'UniformOutput', false); % Corrected headers
exportData(2:end, 1) = sampleData(:, 1); % Sample names
exportData(2:end, 2:end) = num2cell(alignedIntensities); % Intensity values

% Convert cell array to table
alignedTable = cell2table(exportData(2:end, :), 'VariableNames', exportData(1, :));

% Save table as an Excel file
writetable(alignedTable, outputFileName, 'Sheet', 'Aligned Data', 'WriteMode', 'overwrite');

fprintf('Peak alignment completed. Data saved to %s\n', outputFileName);


%% 🔥 Visualization 1: Heatmap of Aligned Intensities
figure;
imagesc(alignedIntensities); % Display intensity matrix as a heatmap
colormap('jet'); % Use a color map for better contrast
colorbar; % Add color scale
xticks(1:length(alignedMZ)); % Set x-axis ticks
xticklabels(cellfun(@num2str, num2cell(alignedMZ'), 'UniformOutput', false)); % Label x-axis with aligned m/z values
yticks(1:length(sampleData)); % Set y-axis ticks
yticklabels(sampleData(:, 1)); % Label y-axis with sample names
xlabel('Aligned m/z values');
ylabel('Samples');
title('Heatmap of Aligned MS Peak Intensities');

%% 🔵 Visualization 2: Scatter Plot of Aligned Peaks
figure;
hold on;
colors = lines(length(expFiles)); % Generate distinct colors for each sample

for i = 1:length(expFiles)
    scatter(alignedMZ, alignedIntensities(i, :), 50, colors(i, :), 'filled'); % Scatter plot
end

legend(sampleData(:, 1), 'Location', 'bestoutside'); % Add legend for samples
xlabel('Aligned m/z values');
ylabel('Intensity');
title('Scatter Plot of Aligned MS Peaks');
grid on;
hold off;
