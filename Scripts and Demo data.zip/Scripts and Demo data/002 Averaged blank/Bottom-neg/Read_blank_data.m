folder_path = 'C:\Users\paxrc6\Desktop\Data processing\Averaged blank\Bottom-neg\';  % Folder containing blank samples
output_file = 'C:\Users\paxrc6\Desktop\Data processing\Averaged blank\Bottom-neg\aligned_blank_peaks.txt';  % Output file

align_blank_samples(folder_path, output_file);
