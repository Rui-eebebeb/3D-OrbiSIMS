% MATLAB Script to Compute Fold Change Using Group Labels and Export Results

% Select file using a dialog box
[filename, filepath] = uigetfile('*.xlsx', 'Select an Excel file');
if filename == 0
    error('No file selected. Please select a valid Excel file.');
end
fullFileName = fullfile(filepath, filename);

% Load the table, keeping original column names
data = readtable(fullFileName, 'VariableNamingRule', 'preserve');

% Extract sample names and group labels
sampleNames = string(data{:, 1});
groupLabels = strtrim(string(data{:, 2}));

% Get unique group names
uniqueGroups = unique(groupLabels);
if numel(uniqueGroups) ~= 2
    disp('Detected group labels:');
    disp(uniqueGroups);
    error('Exactly two unique group labels are required.');
end

group1_label = uniqueGroups(1);
group2_label = uniqueGroups(2);

% Get indices for each group
group1_idx = groupLabels == group1_label;
group2_idx = groupLabels == group2_label;

% Get sample names per group
group1_names = sampleNames(group1_idx);
group2_names = sampleNames(group2_idx);

% Extract intensity matrix
intensityData = table2array(data(:, 3:end));
numSamples = size(intensityData, 1);

% Compute mean intensities per group
mean_group1 = mean(intensityData(group1_idx, :), 1);
mean_group2 = mean(intensityData(group2_idx, :), 1);

% Fix divide-by-zero issues
mean_group1(mean_group1 == 0) = eps;
mean_group2(mean_group2 == 0) = eps;

% Compute fold change and log2 fold change
fold_change = mean_group1 ./ mean_group2;
log2_fold_change = log2(fold_change);

% Build results table
ionNames = data.Properties.VariableNames(3:end);
results = table(string(ionNames)', fold_change', log2_fold_change', ...
    'VariableNames', {'Ion', 'Fold_Change', 'Log2_Fold_Change'});

% Try to sort by numeric ion m/z if possible
numericIons = str2double(results.Ion);
if all(~isnan(numericIons))
    results.Ion = numericIons;
    results = sortrows(results, 'Ion', 'ascend');
else
    results = sortrows(results, 'Ion', 'ascend');
end

% Save to Excel
output_filename = fullfile(filepath, ['Fold_Change_Results_', filename]);
writetable(results, output_filename);

% Display comparison direction and group info
comparisonMessage = sprintf(['Fold change was calculated as:\n\n' ...
    '    %s  ÷  %s\n\n' ...
    'So:\n' ...
    '    Fold Change > 1  →  Higher in %s\n' ...
    '    Fold Change < 1  →  Higher in %s\n' ...
    '    Log2FC > 0       →  Up in %s\n' ...
    '    Log2FC < 0       →  Up in %s\n\n' ...
    'Samples in %s:\n%s\n\nSamples in %s:\n%s\n'], ...
    group1_label, group2_label, ...
    group1_label, group2_label, ...
    group1_label, group2_label, ...
    group1_label, strjoin(group1_names, ', '), ...
    group2_label, strjoin(group2_names, ', '));

disp('---------------------------------------------');
disp(comparisonMessage);
disp('---------------------------------------------');

msgbox(comparisonMessage, 'Comparison Info', 'help');

disp(['Fold change results saved to: ', output_filename]);
