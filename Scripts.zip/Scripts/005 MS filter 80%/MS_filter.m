% MS Peak Filtering Script with User-Defined Threshold
% - Filters ions present in at least a user-specified percentage of samples.
% - Processes multiple Excel files separately.
% - Saves each filtered dataset as a separate Excel file.

clear; clc;

% Let user select one or more Excel files
[fileNames, filePath] = uigetfile('*.xlsx', 'Select One or More Aligned MS Peaks Excel Files', 'MultiSelect', 'on');

% Check if the user canceled the selection
if isequal(fileNames, 0)
    error('No file selected. Process aborted.');
end

% Ensure fileNames is a cell array (for single-file selection)
if ischar(fileNames)
    fileNames = {fileNames};
end

% Ask the user to specify the presence threshold (default: 80%)
presenceThreshold = inputdlg('Enter the minimum presence percentage of ions (0-100, default: 80):', ...
    'Presence Threshold', [1 50], {'80'});

% Convert input to a number
presenceThreshold = str2double(presenceThreshold{1});

% Validate input (default to 80% if invalid)
if isnan(presenceThreshold) || presenceThreshold <= 0 || presenceThreshold > 100
    presenceThreshold = 80;
end

fprintf('Using a presence threshold of %.1f%%.\n', presenceThreshold);

% Process each selected file separately
for i = 1:length(fileNames)
    inputFile = fullfile(filePath, fileNames{i});
    outputFile = fullfile(filePath, ['Filtered_' fileNames{i}]); % Unique output file per input file

    % Get sheet names dynamically
    [~, sheetNames] = xlsfinfo(inputFile);
    
    % Use "Aligned Data" if found, otherwise default to the first sheet
    if any(strcmp(sheetNames, 'Aligned Data'))
        sheetToRead = 'Aligned Data';
    else
        sheetToRead = sheetNames{1}; % Default to the first sheet
        warning('Sheet "Aligned Data" not found in %s. Using first available sheet: %s', fileNames{i}, sheetToRead);
    end

    % Read the Excel file (Preserve column names)
    dataTable = readtable(inputFile, 'Sheet', sheetToRead, 'VariableNamingRule', 'preserve');

    % Extract column names (m/z values) and sample names
    mzValues = dataTable.Properties.VariableNames(2:end); % Ignore first column (Sample names)
    sampleNames = dataTable.Sample; % First column is sample names
    intensityMatrix = table2array(dataTable(:, 2:end)); % Convert intensity values to matrix

    % Determine presence percentage for each ion (m/z column)
    numSamples = size(intensityMatrix, 1);
    presenceCount = sum(intensityMatrix > 0, 1); % Count nonzero intensities
    presencePercentage = (presenceCount / numSamples) * 100; % Convert to percentage

    % Apply filtering based on user-defined presence threshold
    ionsToKeep = presencePercentage >= presenceThreshold;
    filteredMZValues = mzValues(ionsToKeep);
    filteredIntensityMatrix = intensityMatrix(:, ionsToKeep);

    fprintf('File %s: Retained %d out of %d ions after filtering.\n', fileNames{i}, sum(ionsToKeep), length(mzValues));

    % Prepare the new table for exporting
    filteredTable = array2table(filteredIntensityMatrix, 'VariableNames', filteredMZValues);
    filteredTable = addvars(filteredTable, sampleNames, 'Before', 1, 'NewVariableNames', {'Sample'});

    % Save the processed data to a new Excel file (separate file for each input)
    writetable(filteredTable, outputFile, 'Sheet', 'Filtered Data', 'WriteMode', 'overwrite');

    fprintf('Filtered data saved to: %s\n', outputFile);
end

fprintf('Processing completed for all selected files. Each file is processed separately.\n');
