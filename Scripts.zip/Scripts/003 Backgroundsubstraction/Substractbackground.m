% Background Subtraction Script with User-Defined Parameters and Visualization
% - User selects one blank sample and multiple experimental samples.
% - User sets intensity threshold multiplier (default: 3×).
% - User sets mass tolerance in ppm (default: 5 ppm).
% - Ensures that only one blank sample is selected.
% - Outputs background-subtracted experimental data with visual plots.

clear; clc;

% --- Select the Blank Sample ---
uiwait(msgbox('Please select ONLY ONE blank sample file.', 'Select Blank Sample', 'modal'));
[blankFile, blankPath] = uigetfile('*.txt', 'Select the blank sample file', 'MultiSelect', 'on');

% Check if user canceled selection
if isequal(blankFile, 0)
    error('No blank sample selected. Process aborted.');
end

% Ensure only ONE blank sample is selected
if iscell(blankFile)
    errordlg('You must select ONLY ONE blank sample file.', 'Selection Error', 'modal');
    error('Multiple blank samples selected. Please select only one.');
end

% Load blank data
blankData = readmatrix(fullfile(blankPath, blankFile));

% --- Select Experimental Sample Files ---
uiwait(msgbox('Now select one or more experimental sample files.', 'Select Experimental Samples', 'modal'));
[expFiles, expPath] = uigetfile('*.txt', 'Select experimental sample files', 'MultiSelect', 'on');

% Check if user canceled selection
if isequal(expFiles, 0)
    error('No experimental samples selected. Process aborted.');
end

% Convert single file selection to cell array for consistency
if ischar(expFiles)
    expFiles = {expFiles};
end

% --- Get User-Defined Parameters ---
% Mass tolerance input
massTolerance = inputdlg('Enter the mass tolerance in ppm (default: 5):', ...
    'Mass Tolerance', [1 50], {'5'});
massTolerance = str2double(massTolerance{1});
if isnan(massTolerance) || massTolerance <= 0
    massTolerance = 5;
end

% Intensity threshold multiplier input
intensityThreshold = inputdlg('Enter the intensity threshold multiplier (default: 3):', ...
    'Intensity Threshold', [1 50], {'3'});
intensityThreshold = str2double(intensityThreshold{1});
if isnan(intensityThreshold) || intensityThreshold <= 0
    intensityThreshold = 3;
end

fprintf('Using mass tolerance: %.1f ppm\n', massTolerance);
fprintf('Using intensity threshold multiplier: %.1fx\n', intensityThreshold);

% --- Process Each Experimental Sample ---
for i = 1:length(expFiles)
    expData = readmatrix(fullfile(expPath, expFiles{i}));
    
    % Initialize lists for retained and removed ions
    retained_ions = [];
    removed_ions = [];
    
    % Loop through each ion in the experimental sample
    for j = 1:size(expData, 1)
        mz_exp = expData(j, 1);
        intensity_exp = expData(j, 2);
        
        % Find matching ions in blank sample within the user-defined mass tolerance
        mz_diff_signed = (blankData(:,1) - mz_exp) ./ mz_exp * 1e6; % Signed ppm difference
        matching_idx = find(mz_diff_signed >= -massTolerance & mz_diff_signed <= massTolerance);
        
        if isempty(matching_idx)
            % If the ion is not in the blank sample, keep it as is
            retained_ions = [retained_ions; mz_exp, intensity_exp];
        else
            % If the ion exists in the blank sample, check intensity conditions
            intensity_blank = max(blankData(matching_idx, 2)); % Take the highest intensity match
            
            if intensity_exp > intensity_blank
                if intensity_exp >= intensityThreshold * intensity_blank
                    % Subtract intensity and keep the corrected value
                    corrected_intensity = intensity_exp - intensity_blank;
                    if corrected_intensity > 0
                        retained_ions = [retained_ions; mz_exp, corrected_intensity];
                    end
                else
                    % Below threshold, remove ion
                    removed_ions = [removed_ions; mz_exp, intensity_exp];
                end
            else
                % Remove ion (blank intensity is greater)
                removed_ions = [removed_ions; mz_exp, intensity_exp];
            end
        end
    end
    
    % Generate output filename
    [~, name, ~] = fileparts(expFiles{i});
    outputFile = fullfile(expPath, [name, '_background_subtracted.txt']);

    % Open the file for writing
    fid = fopen(outputFile, 'w');

    % Write the header
    fprintf(fid, 'm/z\tIntens.\n');

    % Write each retained ion
    for k = 1:size(retained_ions, 1)
       fprintf(fid, '%.4f\t%.2f\n', retained_ions(k, 1), retained_ions(k, 2));
    end

    % Close file
    fclose(fid);

    % Print message to console
    fprintf('Processed file: %s -> Output: %s\n', expFiles{i}, outputFile);
    
    % --- Visualization: Scatter Plots ---
    figure;
    
    % Plot original experimental data
    subplot(2,1,1);
    scatter(expData(:,1), expData(:,2), 15, 'b', 'filled'); hold on;
    scatter(removed_ions(:,1), removed_ions(:,2), 15, 'r', 'filled');
    title(sprintf('Original vs Removed Ions for %s', expFiles{i}), 'Interpreter', 'none');
    xlabel('m/z'); ylabel('Intensity');
    legend({'Original Ions', 'Removed Ions'}, 'Location', 'northeast');
    grid on;
    
    % Plot retained ions
    subplot(2,1,2);
    scatter(retained_ions(:,1), retained_ions(:,2), 15, 'g', 'filled');
    title(sprintf('Retained Ions for %s', expFiles{i}), 'Interpreter', 'none');
    xlabel('m/z'); ylabel('Intensity');
    legend({'Retained Ions'}, 'Location', 'northeast');
    grid on;
    
    % Save the plot as an image
    saveas(gcf, fullfile(expPath, [name, '_background_subtraction_plot.png']));
end

msgbox('Background subtraction completed successfully!', 'Success', 'modal');
disp('Background subtraction completed successfully.');
