function align_blank_samples(folder_path, output_filename)
    % Align peaks from all blank sample files in a given folder and compute average intensity.
    % INPUT:
    % folder_path     : Folder containing blank sample .txt files
    % output_filename : Name of the output file

    % Get all blank sample files in the folder
    file_list = dir(fullfile(folder_path, '*.txt'));

    % Check if there are any files
    if isempty(file_list)
        error('No blank sample .txt files found in the folder: %s', folder_path);
    end

    % Initialize peak storage
    all_peaks = [];

    % Read each blank sample file
    for i = 1:length(file_list)
        file_path = fullfile(folder_path, file_list(i).name);
        
        % Read the file (assumes tab-delimited, two columns: m/z and Intensity)
        data = readtable(file_path, 'Delimiter', '\t', 'ReadVariableNames', false);
        
        % Ensure correct format
        if size(data, 2) < 2
            warning('Skipping %s: Incorrect format.', file_path);
            continue;
        end

        % Extract m/z and intensity values
        mz_values = data{:, 1};  
        intensity_values = data{:, 2};  

        % Store peaks
        all_peaks = [all_peaks; mz_values, intensity_values];  
    end

    % Sort peaks by m/z for better clustering
    all_peaks = sortrows(all_peaks, 1);

    % Perform hierarchical clustering to align peaks
    mz_values = all_peaks(:, 1);
    intensities = all_peaks(:, 2);

    % Set m/z tolerance for alignment (adjustable)
    mz_tolerance = 0.005;

    % Clustering peaks using hierarchical clustering
    tree = linkage(pdist(mz_values), 'single');
    clusters = cluster(tree, 'cutoff', mz_tolerance, 'criterion', 'distance');

    % Compute average m/z and intensity for each cluster
    unique_clusters = unique(clusters);
    aligned_peaks = zeros(length(unique_clusters), 2);

    for j = 1:length(unique_clusters)
        cluster_idx = (clusters == unique_clusters(j));
        aligned_peaks(j, 1) = mean(mz_values(cluster_idx));  % Average m/z
        aligned_peaks(j, 2) = mean(intensities(cluster_idx)); % Average intensity
    end

    % Sort results by m/z
    aligned_peaks = sortrows(aligned_peaks, 1);

    % Ensure m/z values are formatted to 5 decimal places
    aligned_peaks(:,1) = round(aligned_peaks(:,1), 5);

    % Save output to a TXT file with 5 decimal places formatting and a header
    fileID = fopen(output_filename, 'w');
    fprintf(fileID, 'm/z\tIntens.\n');  % Add header

    for i = 1:size(aligned_peaks, 1)
        fprintf(fileID, '%.5f\t%.5f\n', aligned_peaks(i, 1), aligned_peaks(i, 2));
    end
    fclose(fileID);

    % Display notification
    msgbox(sprintf('Aligned peak list saved to: %s', output_filename), 'Processing Complete');
    fprintf('Aligned peak list saved to: %s\n', output_filename);
end
